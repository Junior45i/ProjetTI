<?php
define('WEBSITE_NAME','GossipHelha');
?>