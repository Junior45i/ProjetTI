<?php
// Redirection de l'index.php
require("includes/fonctions.php");
redirect("connection");